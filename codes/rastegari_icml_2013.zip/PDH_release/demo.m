 addpath(genpath('./'));
 load Main_Data_Pascal.mat
% % I just reduce the dimension for convenience  
  [Text_Feature]=pca2(Text_Feature);
  Text_Feature=Text_Feature(:,1:200);
%


% Random sampling of data for training the hash function 
r=randperm(length(Visual_Feature(:,1)));

model=PDH_train(Visual_Feature(r(1:500),:)',Text_Feature(r(1:500),:)');

 txt_binary=svm_multilabel_predict(Text_Feature',model.txt_model)>0;
 img_binary=svm_multilabel_predict(Visual_Feature',model.img_model)>0;
 