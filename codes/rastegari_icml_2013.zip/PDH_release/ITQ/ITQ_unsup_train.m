function model=ITQ_unsup_train(train_data,nbits,niter)
[n_tr m_tr]=size(train_data);
% center the data, VERY IMPORTANT
sampleMean = mean(train_data,1);
train_data = (train_data - repmat(sampleMean,size(train_data,1),1));


%         [pc, l] = eigs(cov(train_data(1:n_tr,:)),nbits);
%         train_data = train_data * pc;
%PCA


[~,wx,~] = pca2(train_data');
train_data=train_data*real(wx(:,1:nbits));
% ITQ
[~, R] = ITQ(train_data,niter);
% train_data = train_data*R;
% Y = zeros(size(train_data));
% Y(train_data>=0) = 1;

model.R=R;
model.sampleMean=sampleMean;
model.wx=wx;
model.nbits=nbits;

