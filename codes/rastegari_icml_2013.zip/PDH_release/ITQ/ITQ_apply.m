function [H, Er] =ITQ_apply(data,model)


data = (data - repmat(model.sampleMean,size(data,1),1));
data=data*real(model.wx(:,1:model.nbits));
H=data*model.R;
Er=sqrt(sum(sum((H-(2*(H>0)-1)).^2)));


