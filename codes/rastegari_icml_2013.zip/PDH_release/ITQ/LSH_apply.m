function H=LSH_apply(XX,nbits)
%% XX is  data
        XX = XX * randn(size(XX,2),nbits);
        H=(XX>=0);
        