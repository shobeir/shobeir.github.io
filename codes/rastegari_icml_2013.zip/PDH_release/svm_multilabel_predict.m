function pr_label=svm_multilabel_predict(test_data,model)
[m n]=size(test_data);
pr_label=2*(model.w*[test_data; ones(1,n)]>0)-1;
