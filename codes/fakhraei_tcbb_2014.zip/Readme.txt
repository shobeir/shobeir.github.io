Please find the data and code here:
https://github.com/shobeir/fakhraei_tcbb2014

